import plotly.graph_objects as go
import pandas as pd
from plotly.subplots import make_subplots

def process_df(df,side):
    try:
        df = df.dropna()
        Max=df.operacion.value_counts().max()
        DF=pd.DataFrame(columns=['finish','BUY','SELL'], index=range(Max))
        g = df[['operacion','avg_price']].groupby('operacion')

        if side == 'LONG':
            DF.BUY = g.get_group('BUY').avg_price.values
            if g.get_group('SELL').avg_price.values.shape[0] < Max:
                DF.SELL.iloc[:Max-1] = g.get_group('SELL').avg_price.values
                DF['finish'].iloc[:Max-1] = df.start[df.operacion=='SELL'].values
            else:
                DF['finish'] = df.start[df.operacion=='SELL'].values
                DF.SELL = g.get_group('SELL').avg_price.values
        else:

            DF.SELL = g.get_group('SELL').avg_price.values
            if g.get_group('BUY').avg_price.values.shape[0] < Max:
                DF['finish'].iloc[:Max-1] = df.start[df.operacion=='BUY'].values
                DF.SELL.iloc[:Max-1] = g.get_group('BUY').avg_price.values
            else:
                DF['finish'] = df.start[df.operacion=='BUY'].values
                DF.SELL = g.get_group('BUY').avg_price.values

        DF['gain_ptc'] = (DF[['BUY','SELL']].pct_change(axis=1)*100).iloc[:,-1]

        DF = DF.dropna()
        if side == 'SHORT':
            DF.gain_ptc = -DF.gain_ptc
    except:
        DF=pd.DataFrame(columns=['finish', 'BUY', 'SELL', 'gain_ptc'])
    return DF

def candlestick(df,side,leverage, capital):
    fig = make_subplots(
        rows=2, cols=2, row_heights=[0.7, 0.3], column_widths=[0.8, 0.2],
        specs=[[{}, {"rowspan": 2}],
               [{}, None]],
        shared_xaxes=True,
        vertical_spacing=0.1,
        horizontal_spacing=0.05,
        subplot_titles=("Candles", "Trades", "cumulative Gain"))

    fig.add_trace(go.Candlestick(x=df['start'],
                    open=df['open'], high=df['high'],
                    low=df['low'], close=df['close'], name='Candles'),
                  row=1, col=1)
    fig.add_trace(go.Scatter(x=df.start, y=df.EMA_F,
                             mode='lines',
                             name='EMA F'),
                  row=1, col=1)
    fig.add_trace(go.Scatter(x=df.start, y=df.EMA_S,
                             mode='lines',
                             name='EMA S'),
                  row=1, col=1)
    df = df.dropna()
    fig.add_trace(go.Scatter(x=df.start[df.operacion=='BUY'], y=df.avg_price[df.operacion=='BUY'],
                             mode='markers',
                             name='buy',
                             marker_size=20,
                             marker_symbol="triangle-up",
                             marker_color="green"),
                  row=1, col=1)

    fig.add_trace(go.Scatter(x=df.start[df.operacion=='SELL'], y=df.avg_price[df.operacion=='SELL'],
                             mode='markers',
                             name='sell',
                             marker_size=20,
                             marker_symbol="triangle-down",
                             marker_color="red"),
                  row=1, col=1)
    DF = process_df(df,side)



    fig.add_trace(go.Bar( x=['Positive','Negative'], y=[DF[DF.gain_ptc > 0].shape[0],DF[DF.gain_ptc < 0].shape[0]], name='Trades'),row=1, col=2)

    fig.add_trace(go.Scatter(x=DF.finish, y=(DF.gain_ptc*capital*leverage).cumsum(), line= {'shape':'hv'},mode='lines', type='scatter',name='Gain'),
                  row=2, col=1)





    fig.update_layout(xaxis_rangeslider_visible=False)
    return fig






