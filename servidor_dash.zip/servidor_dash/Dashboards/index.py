from sys import path
path.append('../Futuros')
import dash
from dash.dependencies import Input, Output
import dash_html_components as html
import dash_core_components as dcc
import dash_daq as daq
from Bot import CriptoBot_F
from multiprocessing import Process
from Pages import *
import pandas as pd
global last_click, DISABLED
import dash_auth

#default variable
key = '3twyIVmgSoinkU39hx2Mubt8bREk3O2k2lSfw29LNDfw7u57twEUNQLbvQiJBTVu'
secret = 'AY01aIZp5yB77sfXnqx34xDvz9xdq0HvZK6evRFze8QWAEdYG5uyDRPsjocUW3Mv'
cripto = 'BTC'
ref = 'USDT'
EMA_F = 10
EMA_S = 20
period = '1m'
side = 'LONG'
leverage = 40
capital = 4

global VALUES, P

VALUES = {'key': key, 'secret': secret, 'cripto':cripto,'ref':ref,'EMA_F':EMA_F,'EMA_S':EMA_S,'period':period,
          'leverage':leverage, 'capital': capital, 'side':side}

last_click = 0



VALID_USERNAME_PASSWORD_PAIRS = {
    'Gbon': '1234'
}

external_stylesheets = ['https://codepen.io/chriddyp/pen/bWLwgP.css']

app = dash.Dash(__name__, external_stylesheets=external_stylesheets)
auth = dash_auth.BasicAuth(
    app,
    VALID_USERNAME_PASSWORD_PAIRS
)
server = app.server
def monitor(df,side,leverage, capital):
    fig = candlestick(df,side,leverage, capital)
    monitor = html.Div([ html.H2('Graficas')
        ,
        dcc.Graph(figure=fig)
    ])
    return monitor

def config(key,secret,cripto,ref,EMA_F, EMA_S, leverage, capital, side, period):
    config = html.Div( [html.H2('Write api-key and api-secret')] + [html.H5('Api key')]+[ dcc.Input(
                id="input_key",
                value=key,
            )
    ] + [html.H5('Api secret')] + [ dcc.Input(
                id="input_secret",
                value=secret,
            )] +
    [html.Div([html.H2('Write exchange')]+ [html.H5('Cripto')] + [  dcc.Input(
                id="input_cripto",
                value=cripto
            )
    ] + [html.H5('Stable coin')] + [ dcc.Input(
                id="input_ref",
                value=ref,
            )])]+
    [html.Div([html.H2('Select EMA periods')]+ [html.H5('EMA Fast')]+[  dcc.Input(
                id="input_EMA_F",
                value=EMA_F
            )
    ]+ [html.H5('EMA Slow')]+ [ dcc.Input(
                id="input_EMA_S",
                value=EMA_S,
            )])]+
    [html.Div([html.H2("Select leverage and single operation's capital")]+ [html.H5('Leverage')]+[  dcc.Input(
                id="input_leverage",
                value=leverage,
            )
    ]+ [html.H5('Single operation capital')]+ [ dcc.Input(
                id="input_capital",
                value=capital,
            )])]+
    [html.Div([html.H2('Select side')]+[ dcc.Dropdown(
                id="input_side",
                options=[{'label':'SHORT','value':'SHORT'},{'label':'LONG','value':'LONG'}], value=side, style={"width": "50%"}
            )
    ])]+
    [html.Div([html.H2('Select candels periods')]+[  dcc.Dropdown(
                id="input_period",
        options=[{'label':'1m','value':'1m'},{'label':'3m','value':'3m'},{'label':'15m','value':'15m'},
                 {'label':'30m','value':'30m'},{'label':'1h','value':'1h'}],
        value=period, style={"width": "50%"}
            )
    ])]
    + [html.Div(id="out-all-types")])

    return config




bot = CriptoBot_F()
P = Process(target=bot.run)





app.layout = html.Div([html.Div(id='boolean-switch-output'),
                       daq.BooleanSwitch(id='my-boolean-switch', on=False, label="Press to start and stop the Bot"),
html.Button('Refresh', id='button',n_clicks=0)
])

@app.callback(
    Output("out-all-types", "children"),
    [Input("input_key",'value'),Input("input_secret",'value'),Input("input_cripto",'value'),Input("input_ref",'value'),
     Input("input_EMA_F",'value'),Input("input_EMA_S",'value'),Input("input_leverage",'value'),Input("input_capital",'value'),
     Input("input_side",'value'),Input("input_period",'value')],
)
def cb_render(*vals):
    global  VALUES
    VALUES = {'key': vals[0], 'secret': vals[1], 'cripto': vals[2], 'ref': vals[3], 'EMA_F': int(vals[4]), 'EMA_S': int(vals[5]),
              'leverage': int(vals[6]), 'capital': int(vals[7]), 'side': vals[8],'period':vals[9] }
    for v in vals:
        if (v == None or v == ''):
            return 'Not ready to start'

    return 'Ready to start'


@app.callback(
    Output('boolean-switch-output', 'children'),
    [Input('my-boolean-switch', 'on'), Input('button', 'n_clicks')],
)
def update_output(on,n_clicks):

    global last_click , P

    if on == False:
        bot.Run = False
        try:
            P.terminate()
            print('Bot Killed')
            P = Process(target=bot.run)
        except:
            pass
        last_click = n_clicks
        return config(key=VALUES.get('key'),secret=VALUES.get('secret'),cripto=VALUES.get('cripto'),ref=VALUES.get('ref'),
                      EMA_F=VALUES.get('EMA_F'), EMA_S=VALUES.get('EMA_S'), leverage=VALUES.get('leverage'),
                      capital=VALUES.get('capital'), side=VALUES.get('side'), period=VALUES.get('period'))

    if on:

        if n_clicks > last_click:
            df = pd.read_csv('./{}_{}_{}_{}_{}.csv'.format(VALUES.get('cripto')+VALUES.get('ref'), VALUES.get('period'),
                                                           VALUES.get('EMA_F'),VALUES.get('EMA_S'),VALUES.get('side')))
            last_click = n_clicks
            return monitor(df,side=VALUES.get('side'),leverage=VALUES.get('leverage'), capital=VALUES.get('capital'))
        else:
            df = pd.DataFrame(columns=['start', 'open', 'high', 'low', 'close', 'volume','EMA_F','EMA_S', 'operacion','avg_price'])
            df.to_csv('./{}_{}_{}_{}_{}.csv'.format(VALUES.get('cripto')+VALUES.get('ref'), VALUES.get('period'),
                                                           VALUES.get('EMA_F'),VALUES.get('EMA_S'),VALUES.get('side')))
            bot.Set_Parameters(api_key=VALUES.get('key'),secret_key=VALUES.get('secret'),cripto=VALUES.get('cripto'),ref=VALUES.get('ref'),
                      EMA_F=VALUES.get('EMA_F'), EMA_S=VALUES.get('EMA_S'), leverage=VALUES.get('leverage'),
                      capital=VALUES.get('capital'), side=VALUES.get('side'), period=VALUES.get('period'))

            P.start()
            df = pd.read_csv('./{}_{}_{}_{}_{}.csv'.format(VALUES.get('cripto')+VALUES.get('ref'), VALUES.get('period'),
                                                           VALUES.get('EMA_F'),VALUES.get('EMA_S'),VALUES.get('side')))
            last_click = n_clicks
        return monitor(df,side,leverage, capital)






if __name__ == '__main__':
    app.config.suppress_callback_exceptions = True
    target=app.run_server(debug=True)
