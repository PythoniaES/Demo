from index import server as application
if __name__ == '__main__':
    application.run()
