import time
from utils import *
import datetime as dt
import pytz
import warnings
warnings.filterwarnings('ignore')
from binance_f import *

class CriptoBot_F():
    def __init__(self):
        pass

    def Set_Parameters(self, api_key, secret_key, cripto, ref, leverage, side, capital, EMA_F, EMA_S, period):

        self.client = RequestClient(api_key=api_key, secret_key=secret_key)
        try:
            self.client.change_position_mode(dualSidePosition=True)
        except:
            pass
        self.quantity = None
        self.buysignal = None
        self.sellsignal = None
        self.df = pd.DataFrame(columns=['time', 'open', 'high', 'low', 'close', 'volume','start','EMA_F','EMA_S'])
        self.H_df = pd.DataFrame(columns=['start', 'open', 'high', 'low', 'close', 'volume','EMA_F','EMA_S', 'operacion','avg_price'])
        self.RUN = True
        self.error_update = True
        self.open = None
        self.error_update = True
        self.cripto = cripto
        self.ref = ref
        self.exchange = self.cripto + self.ref
        self.side = side
        self.single_operation_capital = capital
        self.leverage = leverage
        self.EMA_F = EMA_F
        self.EMA_S = EMA_S
        self.interval = period

        try:
            self.client.change_initial_leverage(symbol=self.cripto+self.ref, leverage=self.leverage)
        except:
            self.RUN = False
            print('Error leverage')
        result = self.client.get_exchange_information()
        self.minQty, self.stepSize, self.maxQty = Get_Exchange_filters(result, self.exchange)

        self.maxDeciamlQty = Calculate_max_Decimal_Qty(self.stepSize)

        self.capital = Get_Capital(self.client.get_account_information(), self.ref)

        self.open = self.Position_is_Open()


    def Position_is_Open(self):

        result = self.client.get_all_orders(symbol=self.exchange)
        stop = False
        i = 1
        while not stop:
            try:
                order = result[-i].positionSide
            except:
                return False
            if order == self.side:
                if self.side == 'LONG':
                    if result[-i].side == 'BUY':
                        self.quantity = result[-i].executedQty
                        return True
                    else:
                        return False
                else:
                    if result[-i].side == 'BUY':
                        return False
                    else:
                        self.quantity = result[-i].executedQty
                        return True
            else:
                i+=1
                continue

    def Order(self,side,price):
        Qty = Calculate_Qty(price, self.single_operation_capital*self.leverage, self.minQty, self.maxQty, self.maxDeciamlQty)
        if not Qty:
            self.RUN = False
        if self.side == 'LONG':
            if side == 'BUY':
                self.quantity = Qty
            else:
                pass
        else:
            if side == 'SELL':
                self.quantity = Qty
            else:
                pass


        self.client.post_order(symbol=self.exchange, side=side, ordertype='MARKET', quantity=self.quantity, positionSide=self.side)

    def Parse_data(self, result, limit):
        data = []
        for i in range(limit):
            vela = []
            vela.append(result[i].openTime)
            vela.append(result[i].open)
            vela.append(result[i].high)
            vela.append(result[i].low)
            vela.append(result[i].close)
            vela.append(result[i].volume)
            data.append(vela)
        df = pd.DataFrame(data)
        col_names = ['time', 'open', 'high', 'low', 'close', 'volume']
        df.columns = col_names
        for col in col_names:
            df[col] = df[col].astype(float)
        df['start'] = pd.to_datetime(df['time'] * 1000000)
        df['EMA_F'] = np.nan
        df['EMA_S'] = np.nan
        if self.df.shape[0] != 0:
            if self.df['start'].iloc[-1] == df.start.iloc[-1]:
                pass
            else:
                self.error_update = False
        return df

    def last_data(self):


        if self.df.shape[0] == 0:
            candles = self.client.get_candlestick_data(symbol=self.exchange, interval=self.interval,limit=self.EMA_S + 1)
            self.df = self.Parse_data(candles, limit=self.EMA_S+1)

        else:
            while self.error_update:
                try:

                    candles = self.client.get_candlestick_data(symbol=self.exchange, interval=self.interval, limit=1)
                    df_temp = self.Parse_data(candles, limit=1)
                    time.sleep(3)
                except:
                    print('Wait... Error on data extraction')
            self.df = self.df.append(df_temp, ignore_index=True)
            self.df.drop(index=0, inplace=True)
            self.df.index = list(range(self.EMA_S + 1))


        self.df['EMA_F'] = self.df['close'].ewm(self.EMA_F).mean()
        self.df['EMA_S'] = self.df['close'].ewm(self.EMA_S).mean()

        if self.side == 'LONG':
            self.buysignal = Crossover(self.df.EMA_F.values[-2:], self.df.EMA_S.values[-2:])
            self.sellsignal = Crossover(self.df.EMA_S.values[-2:], self.df.EMA_F.values[-2:])
        else:
            self.buysignal = Crossover(self.df.EMA_S.values[-2:], self.df.EMA_F.values[-2:])
            self.sellsignal = Crossover(self.df.EMA_F.values[-2:], self.df.EMA_S.values[-2:])

        self.H_df = self.H_df.append(self.df.iloc[-1,:])
        self.error_update = True



    def Check_last_operation(self):
        if self.side == 'LONG':
            D = {True:'BUY', False: 'SELL'}
        else:
            D = {True: 'SELL', False: 'BUY'}
        try:
            if self.H_df.operacion[self.H_df.operacion.notna()].values[-1] != D[self.open]:
               self.H_df.operacion.iloc[-1] = D[self.open]
        except:
            if self.open:
                self.H_df.operacion.iloc[-1] = D[self.open]



    def Single_Operation(self):
        self.capital = Get_Capital(self.client.get_account_information(), self.ref)
        if self.capital <= self.single_operation_capital:
            print('money finished')
            self.RUN = False
        self.open = self.Position_is_Open()
        self.last_data()
        price = self.client.get_symbol_price_ticker(symbol=self.cripto + self.ref)[0].price
        self.H_df.avg_price.iloc[-1] = price
        self.Check_last_operation()
        if self.open:
            if self.sellsignal:
                if self.side == 'LONG':
                    side = 'SELL'
                    try:
                        self.Order(side=side,price=price)
                        self.H_df.operacion.iloc[-1] = 'SELL'
                    except Exception as e:
                        print(e)
                        self.H_df.operacion.iloc[-1] = 'ERROR'
                else:
                    side = 'BUY'
                    try:
                        self.Order(side=side,price=price)
                        self.H_df.operacion.iloc[-1] = 'BUY'
                    except:
                        self.H_df.operacion.iloc[-1] = 'ERROR'
        else:
            if self.buysignal:
                if self.side == 'LONG':
                    side = 'BUY'
                    try:
                        self.Order(side=side,price=price)
                        self.H_df.operacion.iloc[-1] = 'BUY'
                    except Exception as e:
                        print(e)
                        self.H_df.operacion.iloc[-1] = 'ERROR'
                else:
                    side = 'SELL'
                    try:
                        self.Order(side=side,price=price)
                        self.H_df.operacion.iloc[-1] = 'SELL'
                    except:
                        self.H_df.operacion.iloc[-1] = 'ERROR'
        self.H_df.to_csv('./{}_{}_{}_{}_{}.csv'.format(self.cripto+self.ref, self.interval, self.EMA_F,self.EMA_S,self.side))


    def run(self):
        if 'm' in self.interval:
            if len(self.interval) == 2:
                step = int(self.interval[0])
            else:
                step = int(self.interval[:2])
        elif self.interval == '1h':
            step = 60
        else:
            print('interval error')
            return
        self.last_data()
        START = self.df.start.iloc[-1] + dt.timedelta(minutes=step)
        print(START)
        while dt.datetime.now(dt.timezone.utc) < pytz.UTC.localize(START):
            time.sleep(1)
            pass
            print('Strarting Bot...\n')
        time.sleep(3)  # para ser seguros de encontrar los datos de la velas siguente
        print('Bot started')
        while self.RUN:
            temp = time.time()
            self.Single_Operation()
            retraso = time.time() - temp
            time.sleep(60 * step - retraso)





