BINANCE = {
  "key": "3twyIVmgSoinkU39hx2Mubt8bREk3O2k2lSfw29LNDfw7u57twEUNQLbvQiJBTVu",
  "secret": "AY01aIZp5yB77sfXnqx34xDvz9xdq0HvZK6evRFze8QWAEdYG5uyDRPsjocUW3Mv"
}

BOTS = 2


LEVERAGE = [30, 30]

CRIPTO = ['ADA', 'ETH']
REF = ['USDT', 'USDT']

PERIOD = ['3m','3m']
SIDE = ['SHORT','LONG']

EMA_F = [12, 12]
EMA_S = [19, 19]

SINGLE_OPERATION_CAPITAL = [4, 4]
