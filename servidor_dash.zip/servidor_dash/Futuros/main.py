from Bot import CriptoBot_F
from config import *
import threading
'''
bot = CriptoBot_F(api_key=BINANCE.get('key'), secret_key=BINANCE.get('secret'))

bot.Set_Parameters( cripto=CRIPTO, ref=REF, leverage=LEVERAGE, side=SIDE, single_operation_capital=SINGLE_OPERATION_CAPITAL, EMA_F=EMA_F, EMA_S=EMA_S, intervals=PERIODS)

bot.run()

'''
bots = []
for i in range(BOTS):
    bots.append(CriptoBot_F())
    bots[i].Set_Parameters(api_key=BINANCE.get('key'), secret_key=BINANCE.get('secret'), cripto=CRIPTO[i], ref=REF[i], leverage=LEVERAGE[i], side=SIDE[i], capital=SINGLE_OPERATION_CAPITAL[i], EMA_F=EMA_F[i], EMA_S=EMA_S[i], period=PERIOD[i])
    threading.Thread(target=bots[i].run).start()
